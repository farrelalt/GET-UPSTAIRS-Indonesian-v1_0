@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"

echo.
echo ============================================
echo   GET UPSTAIRS - Terjemahan Bahasa Indonesia
echo ============================================
echo.

if not exist "GET UPSTAIRS.exe" goto SALAHFOLDER
if not exist "xdelta3.exe" goto NOXDELTA
if not exist "patch\level0.xdelta" goto NOPATCH

set "DATA=GET UPSTAIRS_Data"
set "BACKUP=%DATA%\backup-english"

if exist "%BACKUP%\level0" goto SUDAHADA

echo Membuat backup file asli...
if not exist "%BACKUP%" mkdir "%BACKUP%"
for %%F in (level0 level1 level2 level3 level4 level5 level6 level7) do (
    if exist "%DATA%\%%F" copy /y "%DATA%\%%F" "%BACKUP%\%%F" >nul
)
copy /y "%DATA%\Managed\Assembly-CSharp.dll" "%BACKUP%\Assembly-CSharp.dll" >nul
goto PASANG

:SUDAHADA
echo Terjemahan sepertinya sudah pernah dipasang.
echo.
set /p ULANG="Pasang ulang dari file asli? (y/n): "
if /i not "%ULANG%"=="y" goto BATAL
echo.
echo Mengembalikan file asli dulu...
call :RESTORE
goto PASANG

:PASANG
echo.
echo Memasang terjemahan...
echo.

set GAGAL=0
for %%F in (level0 level1 level2 level3 level4 level5 level6 level7) do call :APPLY "%%F"

if not exist "patch\Managed\Assembly-CSharp.dll.xdelta" goto CEKHASIL
xdelta3.exe -d -f -s "%DATA%\Managed\Assembly-CSharp.dll" "patch\Managed\Assembly-CSharp.dll.xdelta" "%DATA%\Managed\_tmp.dll"
if errorlevel 1 goto DLLGAGAL
move /y "%DATA%\Managed\_tmp.dll" "%DATA%\Managed\Assembly-CSharp.dll" >nul
echo   [OK] Assembly-CSharp.dll
goto CEKHASIL

:DLLGAGAL
if exist "%DATA%\Managed\_tmp.dll" del "%DATA%\Managed\_tmp.dll"
echo   [GAGAL] Assembly-CSharp.dll
set GAGAL=1

:CEKHASIL
echo.
if "%GAGAL%"=="0" goto BERHASIL

echo ============================================
echo   ADA YANG GAGAL
echo ============================================
echo.
echo Kemungkinan versi game kamu berbeda dengan
echo versi yang dipakai untuk membuat patch ini.
echo.
echo Mengembalikan file asli...
call :RESTORE
echo Selesai. Game kembali seperti semula.
echo.
pause
exit /b 1

:BERHASIL
echo ============================================
echo   BERHASIL! Silakan jalankan gamenya.
echo ============================================
echo.
echo File asli disimpan di folder backup-english.
echo Untuk kembali ke bahasa Inggris, jalankan HAPUS.bat
echo.
pause
exit /b 0

:APPLY
set "NAMA=%~1"
if not exist "patch\%NAMA%.xdelta" goto :eof
xdelta3.exe -d -f -s "%DATA%\%NAMA%" "patch\%NAMA%.xdelta" "%DATA%\_tmp_%NAMA%"
if errorlevel 1 (
    if exist "%DATA%\_tmp_%NAMA%" del "%DATA%\_tmp_%NAMA%"
    echo   [GAGAL] %NAMA%
    set GAGAL=1
    goto :eof
)
move /y "%DATA%\_tmp_%NAMA%" "%DATA%\%NAMA%" >nul
echo   [OK] %NAMA%
goto :eof

:RESTORE
for %%F in (level0 level1 level2 level3 level4 level5 level6 level7) do (
    if exist "%BACKUP%\%%F" copy /y "%BACKUP%\%%F" "%DATA%\%%F" >nul
)
if exist "%BACKUP%\Assembly-CSharp.dll" copy /y "%BACKUP%\Assembly-CSharp.dll" "%DATA%\Managed\Assembly-CSharp.dll" >nul
goto :eof

:BATAL
echo Dibatalkan.
echo.
pause
exit /b 0

:SALAHFOLDER
echo [GAGAL] File ini harus ditaruh di folder game.
echo.
echo Pindahkan SEMUA isi zip ini ke folder yang berisi
echo "GET UPSTAIRS.exe", lalu jalankan lagi.
echo.
pause
exit /b 1

:NOXDELTA
echo [GAGAL] xdelta3.exe tidak ditemukan.
echo Pastikan semua isi zip sudah diextract.
echo.
pause
exit /b 1

:NOPATCH
echo [GAGAL] Folder "patch" tidak ditemukan atau kosong.
echo Pastikan semua isi zip sudah diextract.
echo.
pause
exit /b 1