@echo off
setlocal
cd /d "%~dp0"

echo.
echo ============================================
echo   Mengembalikan ke Bahasa Inggris
echo ============================================
echo.

if not exist "GET UPSTAIRS.exe" goto SALAHFOLDER

set "DATA=GET UPSTAIRS_Data"
set "BACKUP=%DATA%\backup-english"

if not exist "%BACKUP%\level0" goto NOBACKUP

for %%F in (level0 level1 level2 level3 level4 level5 level6 level7) do (
    if exist "%BACKUP%\%%F" copy /y "%BACKUP%\%%F" "%DATA%\%%F" >nul
)
if exist "%BACKUP%\Assembly-CSharp.dll" copy /y "%BACKUP%\Assembly-CSharp.dll" "%DATA%\Managed\Assembly-CSharp.dll" >nul

echo Selesai. Game sudah kembali ke bahasa Inggris.
echo.
echo Folder backup-english boleh dihapus kalau kamu
echo tidak berencana memasang terjemahan lagi.
echo.
pause
exit /b 0

:NOBACKUP
echo [GAGAL] Backup tidak ditemukan.
echo.
echo Terjemahan belum pernah dipasang, atau folder
echo backup-english sudah terhapus.
echo.
pause
exit /b 1

:SALAHFOLDER
echo [GAGAL] File ini harus ditaruh di folder game.
echo Pindahkan ke folder yang berisi "GET UPSTAIRS.exe".
echo.
pause
exit /b 1