=== GET UPSTAIRS - Terjemahan Bahasa Indonesia ===

Penerjemah: Althaf Farrel
Versi mod: 1.0
Untuk versi game: [isi versi gamenya]
Game asli oleh: Joseph Mularczyk

--- CARA PASANG ---

1. Extract semua isi zip ini ke folder game
   (folder yang berisi "GET UPSTAIRS.exe")
2. Klik dua kali PASANG.bat
3. Selesai, jalankan gamenya

--- CARA HAPUS ---

Klik dua kali HAPUS.bat
Game kembali ke bahasa Inggris.

--- CATATAN ---

Mod ini TIDAK berisi game. Yang dibagikan hanya file patch,
jadi kamu harus punya game aslinya.

Download game di: [link itch.io]

Patch ini hanya bekerja pada versi game yang disebut di atas.
Kalau versimu berbeda, PASANG.bat akan gagal dan menampilkan error.

--- LISENSI ---

Paket ini menyertakan xdelta3 (GPL). Lihat COPYING-xdelta.txt.
Source code: https://github.com/jmacd/xdelta-gpl

--- LAPOR KESALAHAN ---

[kontakmu]